namespace SeguroSocial;

partial class Form1
{
    private System.ComponentModel.IContainer? components = null;

    private Label lblNome = null!;
    private Label lblAnoNascimento = null!;
    private Label lblSalario = null!;
    private TextBox txtNome = null!;
    private TextBox txtAnoNascimento = null!;
    private TextBox txtSalario = null!;

    private GroupBox grpSexo = null!;
    private RadioButton rdbMasculino = null!;
    private RadioButton rdbFeminino = null!;

    private GroupBox grpTime = null!;
    private RadioButton rdbCorinthians = null!;
    private RadioButton rdbSaoPaulo = null!;
    private RadioButton rdbSantos = null!;
    private RadioButton rdbPalmeiras = null!;

    private CheckBox chkFaculdade = null!;

    private GroupBox grpArea = null!;
    private RadioButton rdbTecnologica = null!;
    private RadioButton rdbExatas = null!;
    private RadioButton rdbHumanas = null!;

    private Button btnCalcular = null!;
    private Label lblTituloResultado = null!;
    private Label lblValorBonus = null!;
    private Label lblMemoria = null!;
    private TextBox txtMemoria = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
            components.Dispose();

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
        lblNome = new Label();
        lblAnoNascimento = new Label();
        lblSalario = new Label();
        txtNome = new TextBox();
        txtAnoNascimento = new TextBox();
        txtSalario = new TextBox();
        grpSexo = new GroupBox();
        rdbMasculino = new RadioButton();
        rdbFeminino = new RadioButton();
        grpTime = new GroupBox();
        rdbCorinthians = new RadioButton();
        rdbSaoPaulo = new RadioButton();
        rdbSantos = new RadioButton();
        rdbPalmeiras = new RadioButton();
        chkFaculdade = new CheckBox();
        grpArea = new GroupBox();
        rdbTecnologica = new RadioButton();
        rdbExatas = new RadioButton();
        rdbHumanas = new RadioButton();
        btnCalcular = new Button();
        lblTituloResultado = new Label();
        lblValorBonus = new Label();
        lblMemoria = new Label();
        txtMemoria = new TextBox();
        grpSexo.SuspendLayout();
        grpTime.SuspendLayout();
        grpArea.SuspendLayout();
        SuspendLayout();
        // 
        // lblNome
        // 
        lblNome.AutoSize = true;
        lblNome.Location = new Point(25, 22);
        lblNome.Name = "lblNome";
        lblNome.Size = new Size(40, 15);
        lblNome.TabIndex = 0;
        lblNome.Text = "Nome";
        // 
        // lblAnoNascimento
        // 
        lblAnoNascimento.AutoSize = true;
        lblAnoNascimento.Location = new Point(270, 22);
        lblAnoNascimento.Name = "lblAnoNascimento";
        lblAnoNascimento.Size = new Size(96, 15);
        lblAnoNascimento.TabIndex = 2;
        lblAnoNascimento.Text = "Ano Nascimento";
        // 
        // lblSalario
        // 
        lblSalario.AutoSize = true;
        lblSalario.Location = new Point(420, 22);
        lblSalario.Name = "lblSalario";
        lblSalario.Size = new Size(42, 15);
        lblSalario.TabIndex = 4;
        lblSalario.Text = "Salário";
        // 
        // txtNome
        // 
        txtNome.Location = new Point(25, 45);
        txtNome.Name = "txtNome";
        txtNome.Size = new Size(230, 23);
        txtNome.TabIndex = 1;
        // 
        // txtAnoNascimento
        // 
        txtAnoNascimento.Location = new Point(270, 45);
        txtAnoNascimento.Name = "txtAnoNascimento";
        txtAnoNascimento.Size = new Size(135, 23);
        txtAnoNascimento.TabIndex = 3;
        txtAnoNascimento.Validating += txtAnoNascimento_Validating;
        // 
        // txtSalario
        // 
        txtSalario.Location = new Point(420, 45);
        txtSalario.Name = "txtSalario";
        txtSalario.Size = new Size(150, 23);
        txtSalario.TabIndex = 5;
        txtSalario.TextChanged += txtSalario_TextChanged;
        // 
        // grpSexo
        // 
        grpSexo.Controls.Add(rdbMasculino);
        grpSexo.Controls.Add(rdbFeminino);
        grpSexo.Location = new Point(25, 90);
        grpSexo.Name = "grpSexo";
        grpSexo.Size = new Size(230, 145);
        grpSexo.TabIndex = 6;
        grpSexo.TabStop = false;
        grpSexo.Text = "Sexo";
        // 
        // rdbMasculino
        // 
        rdbMasculino.AutoSize = true;
        rdbMasculino.Location = new Point(35, 40);
        rdbMasculino.Name = "rdbMasculino";
        rdbMasculino.Size = new Size(80, 19);
        rdbMasculino.TabIndex = 0;
        rdbMasculino.Text = "Masculino";
        // 
        // rdbFeminino
        // 
        rdbFeminino.AutoSize = true;
        rdbFeminino.Location = new Point(35, 85);
        rdbFeminino.Name = "rdbFeminino";
        rdbFeminino.Size = new Size(75, 19);
        rdbFeminino.TabIndex = 1;
        rdbFeminino.Text = "Feminino";
        // 
        // grpTime
        // 
        grpTime.Controls.Add(rdbCorinthians);
        grpTime.Controls.Add(rdbSaoPaulo);
        grpTime.Controls.Add(rdbSantos);
        grpTime.Controls.Add(rdbPalmeiras);
        grpTime.Location = new Point(275, 90);
        grpTime.Name = "grpTime";
        grpTime.Size = new Size(295, 185);
        grpTime.TabIndex = 7;
        grpTime.TabStop = false;
        grpTime.Text = "Time que Simpatiza";
        // 
        // rdbCorinthians
        // 
        rdbCorinthians.AutoSize = true;
        rdbCorinthians.Location = new Point(35, 30);
        rdbCorinthians.Name = "rdbCorinthians";
        rdbCorinthians.Size = new Size(86, 19);
        rdbCorinthians.TabIndex = 0;
        rdbCorinthians.Text = "Corinthians";
        // 
        // rdbSaoPaulo
        // 
        rdbSaoPaulo.AutoSize = true;
        rdbSaoPaulo.Location = new Point(35, 65);
        rdbSaoPaulo.Name = "rdbSaoPaulo";
        rdbSaoPaulo.Size = new Size(77, 19);
        rdbSaoPaulo.TabIndex = 1;
        rdbSaoPaulo.Text = "São Paulo";
        // 
        // rdbSantos
        // 
        rdbSantos.AutoSize = true;
        rdbSantos.Location = new Point(35, 100);
        rdbSantos.Name = "rdbSantos";
        rdbSantos.Size = new Size(60, 19);
        rdbSantos.TabIndex = 2;
        rdbSantos.Text = "Santos";
        // 
        // rdbPalmeiras
        // 
        rdbPalmeiras.AutoSize = true;
        rdbPalmeiras.Location = new Point(35, 135);
        rdbPalmeiras.Name = "rdbPalmeiras";
        rdbPalmeiras.Size = new Size(76, 19);
        rdbPalmeiras.TabIndex = 3;
        rdbPalmeiras.Text = "Palmeiras";
        // 
        // chkFaculdade
        // 
        chkFaculdade.AutoSize = true;
        chkFaculdade.Location = new Point(25, 260);
        chkFaculdade.Name = "chkFaculdade";
        chkFaculdade.Size = new Size(134, 19);
        chkFaculdade.TabIndex = 8;
        chkFaculdade.Text = "Cursando Faculdade";
        chkFaculdade.CheckedChanged += chkFaculdade_CheckedChanged;
        // 
        // grpArea
        // 
        grpArea.Controls.Add(rdbTecnologica);
        grpArea.Controls.Add(rdbExatas);
        grpArea.Controls.Add(rdbHumanas);
        grpArea.Enabled = false;
        grpArea.Location = new Point(25, 300);
        grpArea.Name = "grpArea";
        grpArea.Size = new Size(545, 125);
        grpArea.TabIndex = 9;
        grpArea.TabStop = false;
        grpArea.Text = "Área";
        // 
        // rdbTecnologica
        // 
        rdbTecnologica.AutoSize = true;
        rdbTecnologica.Location = new Point(25, 30);
        rdbTecnologica.Name = "rdbTecnologica";
        rdbTecnologica.Size = new Size(89, 19);
        rdbTecnologica.TabIndex = 0;
        rdbTecnologica.Text = "Tecnológica";
        // 
        // rdbExatas
        // 
        rdbExatas.AutoSize = true;
        rdbExatas.Location = new Point(25, 60);
        rdbExatas.Name = "rdbExatas";
        rdbExatas.Size = new Size(157, 19);
        rdbExatas.TabIndex = 1;
        rdbExatas.Text = "Não Tecnológica - Exatas";
        // 
        // rdbHumanas
        // 
        rdbHumanas.AutoSize = true;
        rdbHumanas.Location = new Point(25, 90);
        rdbHumanas.Name = "rdbHumanas";
        rdbHumanas.Size = new Size(176, 19);
        rdbHumanas.TabIndex = 2;
        rdbHumanas.Text = "Não Tecnológica - Humanas";
        // 
        // btnCalcular
        // 
        btnCalcular.Image = (Image)resources.GetObject("btnCalcular.Image");
        btnCalcular.ImageAlign = ContentAlignment.MiddleLeft;
        btnCalcular.Location = new Point(25, 431);
        btnCalcular.Name = "btnCalcular";
        btnCalcular.Size = new Size(190, 79);
        btnCalcular.TabIndex = 10;
        btnCalcular.Text = "Calcular Valor Bônus";
        btnCalcular.TextAlign = ContentAlignment.MiddleRight;
        btnCalcular.UseVisualStyleBackColor = true;
        btnCalcular.Click += btnCalcular_Click;
        // 
        // lblTituloResultado
        // 
        lblTituloResultado.AutoSize = true;
        lblTituloResultado.Font = new Font("Segoe UI", 10F);
        lblTituloResultado.Location = new Point(275, 462);
        lblTituloResultado.Name = "lblTituloResultado";
        lblTituloResultado.Size = new Size(82, 19);
        lblTituloResultado.TabIndex = 11;
        lblTituloResultado.Text = "Valor Bônus";
        // 
        // lblValorBonus
        // 
        lblValorBonus.AutoSize = true;
        lblValorBonus.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblValorBonus.Location = new Point(275, 488);
        lblValorBonus.Name = "lblValorBonus";
        lblValorBonus.Size = new Size(117, 25);
        lblValorBonus.TabIndex = 12;
        lblValorBonus.Text = "R$ ???????,??";
        // 
        // lblMemoria
        // 
        lblMemoria.AutoSize = true;
        lblMemoria.Location = new Point(25, 525);
        lblMemoria.Name = "lblMemoria";
        lblMemoria.Size = new Size(113, 15);
        lblMemoria.TabIndex = 13;
        lblMemoria.Text = "Memória do cálculo";
        // 
        // txtMemoria
        // 
        txtMemoria.Location = new Point(155, 522);
        txtMemoria.Multiline = true;
        txtMemoria.Name = "txtMemoria";
        txtMemoria.ReadOnly = true;
        txtMemoria.ScrollBars = ScrollBars.Vertical;
        txtMemoria.Size = new Size(545, 105);
        txtMemoria.TabIndex = 14;
        // 
        // Form1
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(760, 650);
        Controls.Add(lblNome);
        Controls.Add(txtNome);
        Controls.Add(lblAnoNascimento);
        Controls.Add(txtAnoNascimento);
        Controls.Add(lblSalario);
        Controls.Add(txtSalario);
        Controls.Add(grpSexo);
        Controls.Add(grpTime);
        Controls.Add(chkFaculdade);
        Controls.Add(grpArea);
        Controls.Add(btnCalcular);
        Controls.Add(lblTituloResultado);
        Controls.Add(lblValorBonus);
        Controls.Add(lblMemoria);
        Controls.Add(txtMemoria);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        Name = "Form1";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Cálculo de bônus social";
        grpSexo.ResumeLayout(false);
        grpSexo.PerformLayout();
        grpTime.ResumeLayout(false);
        grpTime.PerformLayout();
        grpArea.ResumeLayout(false);
        grpArea.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }
}
