using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace SeguroSocial;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }

    private void chkFaculdade_CheckedChanged(object sender, EventArgs e)
    {
        grpArea.Enabled = chkFaculdade.Checked;

        if (!chkFaculdade.Checked)
        {
            rdbTecnologica.Checked = false;
            rdbExatas.Checked = false;
            rdbHumanas.Checked = false;
        }
    }

    private void txtSalario_TextChanged(object sender, EventArgs e)
    {
        lblValorBonus.Text = "R$ ???????,??";
    }

    private void txtAnoNascimento_Validating(object sender, CancelEventArgs e)
    {
        if (txtAnoNascimento.Text != "")
        {
            if (!int.TryParse(txtAnoNascimento.Text, out _))
            {
                MessageBox.Show("Digite um ano válido.",
                    "Validação",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                e.Cancel = true;
            }
        }
    }

    private void btnCalcular_Click(object sender, EventArgs e)
    {
        // Verificações básicas
        if (txtNome.Text.Trim() == "")
        {
            MessageBox.Show("Digite o nome.");
            txtNome.Focus();
            return;
        }

        if (txtAnoNascimento.Text.Trim() == "")
        {
            MessageBox.Show("Digite o ano de nascimento.");
            txtAnoNascimento.Focus();
            return;
        }

        if (txtSalario.Text.Trim() == "")
        {
            MessageBox.Show("Digite o salário.");
            txtSalario.Focus();
            return;
        }

        // Conversão de tipos
        if (!int.TryParse(txtAnoNascimento.Text, out int anoNascimento))
        {
            MessageBox.Show("Digite um ano de nascimento válido.");
            txtAnoNascimento.Focus();
            return;
        }

        if (!double.TryParse(txtSalario.Text, out double salario))
        {
            MessageBox.Show("Digite um salário válido.");
            txtSalario.Focus();
            return;
        }

        if (anoNascimento < 1900 || anoNascimento > DateTime.Now.Year)
        {
            MessageBox.Show("Digite um ano de nascimento válido.");
            txtAnoNascimento.Focus();
            return;
        }

        // Verifica sexo
        if (!rdbMasculino.Checked && !rdbFeminino.Checked)
        {
            MessageBox.Show("Selecione o sexo.");
            return;
        }

        // Verifica time
        if (!rdbCorinthians.Checked &&
            !rdbSantos.Checked &&
            !rdbSaoPaulo.Checked &&
            !rdbPalmeiras.Checked)
        {
            MessageBox.Show("Selecione o time que simpatiza.");
            return;
        }

        // Inconsistências pedidas no enunciado
        if (rdbMasculino.Checked && rdbSaoPaulo.Checked)
        {
            MessageBox.Show(
                "Inconsistência: pessoas do sexo masculino não podem simpatizar com o São Paulo.",
                "Dados inconsistentes",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        if (anoNascimento > 1970 && rdbSantos.Checked)
        {
            MessageBox.Show(
                "Inconsistência: pessoas nascidas depois de 1970 não podem simpatizar com o Santos.",
                "Dados inconsistentes",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        if (salario > 1500 && rdbCorinthians.Checked)
        {
            MessageBox.Show(
                "Inconsistência: pessoas com salário superior a R$ 1.500,00 não podem simpatizar com o Corinthians.",
                "Dados inconsistentes",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        // Início do cálculo
        double total = 0;
        string memoria = "";

        int idade = DateTime.Now.Year - anoNascimento;
        double bonusIdade = idade * 100;

        total += bonusIdade;
        memoria += $"Idade: {idade} anos x R$ 100,00 = R$ {bonusIdade:N2}\r\n";

        // Sexo
        if (rdbFeminino.Checked)
        {
            total += 1500;
            memoria += "Mulher = R$ 1.500,00\r\n";
        }
        else
        {
            total += 1000;
            memoria += "Homem = R$ 1.000,00\r\n";
        }

        // Nascidos no século XX
        if (anoNascimento >= 1901 && anoNascimento <= 2000)
        {
            total += 500;
            memoria += "Nascido no século 20 = R$ 500,00\r\n";
        }

        // Time
        if (rdbCorinthians.Checked)
        {
            total += 5000;
            memoria += "Corinthians = R$ 5.000,00\r\n";
        }
        else if (rdbSantos.Checked)
        {
            total += 2000;
            memoria += "Santos = R$ 2.000,00\r\n";
        }
        else if (rdbSaoPaulo.Checked)
        {
            total += 1000;
            memoria += "São Paulo = R$ 1.000,00\r\n";
        }
        else if (rdbPalmeiras.Checked)
        {
            total -= 100;
            memoria += "Palmeiras = R$ -100,00\r\n";
        }

        // Salário
        if (salario <= 2500)
        {
            total += 2000;
            memoria += "Salário até R$ 2.500,00 = R$ 2.000,00\r\n";
        }
        else if (salario <= 4500)
        {
            total += 1000;
            memoria += "Salário até R$ 4.500,00 = R$ 1.000,00\r\n";
        }

        // Faculdade
        if (chkFaculdade.Checked)
        {
            total += 5000;
            memoria += "Cursando faculdade = R$ 5.000,00\r\n";

            if (rdbTecnologica.Checked)
            {
                total += 3000;
                memoria += "Área tecnológica = R$ 3.000,00\r\n";
            }
            else if (rdbExatas.Checked)
            {
                total += 2500;
                memoria += "Área de exatas = R$ 2.500,00\r\n";
            }
            else if (rdbHumanas.Checked)
            {
                total += 1000;
                memoria += "Área de humanas = R$ 1.000,00\r\n";
            }
        }

        // Exibição
        lblValorBonus.Text = $"R$ {total:N2}";

        memoria += "\r\n--------------------------------\r\n";
        memoria += $"TOTAL DO BÔNUS = R$ {total:N2}";

        txtMemoria.Text = memoria;
    }
}
