ATIVIDADE - CÁLCULO DE BÔNUS SOCIAL
====================================

Projeto:
SeguroSocial

Tecnologia:
C# / Windows Forms / .NET 8

COMO ABRIR
----------
1. Extraia o arquivo ZIP.
2. Abra o arquivo SeguroSocial.sln no Visual Studio.
3. Se aparecer uma mensagem para restaurar/carregar o projeto, aceite.
4. Pressione F5 para executar.

O projeto foi preparado para a atividade de Windows Forms e contém:
- TextBox para Nome, Ano de Nascimento e Salário
- RadioButton para Sexo
- RadioButton para Time
- CheckBox para Faculdade
- RadioButton para Área
- Button para cálculo
- Label para resultado
- TextBox para memória do cálculo
- Eventos Click, TextChanged e Validating
- Conversão de tipos
- Estruturas if/else
- Verificação das três inconsistências do enunciado

REGRAS IMPLEMENTADAS
--------------------
- R$ 100 por ano de vida
- R$ 1.500 para mulheres
- R$ 1.000 para homens
- R$ 500 para nascidos no século XX
- Corinthians: R$ 5.000
- Santos: R$ 2.000
- São Paulo: R$ 1.000
- Palmeiras: -R$ 100
- Salário até R$ 2.500: R$ 2.000
- Salário até R$ 4.500: R$ 1.000
- Faculdade: R$ 5.000
- Tecnológica: +R$ 3.000
- Exatas: +R$ 2.500
- Humanas: +R$ 1.000

INCONSISTÊNCIAS
---------------
- Homem + São Paulo
- Nascido depois de 1970 + Santos
- Salário maior que R$ 1.500 + Corinthians

OBSERVAÇÃO
----------
O projeto usa .NET 8. Se a sua instalação do Visual Studio não tiver o .NET 8 instalado,
o Visual Studio pode solicitar a instalação do SDK correspondente.
